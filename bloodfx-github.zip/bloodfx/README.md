# My first mod... don't go rough :)
Adds redstone block break particles whenever a player is hit. That's it.
